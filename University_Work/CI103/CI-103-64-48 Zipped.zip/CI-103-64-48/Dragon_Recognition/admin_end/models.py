from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Student(models.Model):  # class student is the database structure for student information
    #user = models.ForeignKey(User, on_delete=models.CASCADE)  # set behavior when deleting foreign key, cascade delete everythign associtate with it
    student_first_name = models.CharField(max_length=35, default='')
    student_last_name = models.CharField(max_length=35, default='')
    student_id = models.CharField(primary_key=True, max_length=12, default='')
    student_photo = models.ImageField(upload_to='student_images', default='')

    class Meta:
        ordering = ('student_first_name', 'student_last_name', 'student_id', 'student_photo')


class Course(models.Model):
    course_id = models.CharField(max_length=10, primary_key=True)
    course_name = models.CharField(max_length=30)
    course_start = models.CharField(max_length=64)
    course_end = models.CharField(max_length=64)


class Schedule_Course(models.Model):
    schedule_course_id = models.CharField(primary_key=True, max_length=64)
    course_id = models.ForeignKey(Course, on_delete=models.CASCADE)
    teacher_id = models.ForeignKey(User, on_delete=models.CASCADE, related_name="Schedule")  # It is User instead of teacher because we are linking it with the actual django user,


class Student_Course(models.Model):
    student_course_id = models.CharField(max_length=64, primary_key=True)
    schedule_course_id = models.ForeignKey(Schedule_Course, on_delete=models.CASCADE, related_name="Schedule_Course")
    student_id = models.ForeignKey(Student, on_delete=models.CASCADE)
    attend = models.BooleanField(default=False)



