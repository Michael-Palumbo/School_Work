function error(feature){ //function to handle functionalities that haven't been created yet
  alert("Hi and Welcome to Dragon Recognition. Unfortunately the " + feature + " feature you clicked on has not yet been implemented.");
}


var loadFile = function(event) { //used to display images on the submit student page
	var image = document.getElementById('displayImage');
	image.src = URL.createObjectURL(event.target.files[0]);
}

function hideOptions(showingID){
  for (id of ["base_id","create_display","class_modify_classes"])
      document.getElementById(id).style.display = "none";
      displayID(showingID)
}

function displayID(showingID){
  showingID.style.display = "block";
}




//Live video for Student Terminal
function loadVideoTerminal(){
  var video = document.getElementById('video');

  // Get access to the camera
  if(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: true }).then(function(stream) {
          video.srcObject = stream;
          video.play();
      });
  }
  var canvas = document.getElementById('test');
    if (canvas == null){
    console.log("Error: canvas is undetected")
    }
  var context = canvas.getContext('2d');
}


//define variables to make reference easier
let credential_type = document.getElementById('enter_credential_type')
let credential_username = document.getElementById('enter_credential_username')
let credential_password = document.getElementById('enter_credential_password')
let credential_password_confirm = document.getElementById('enter_credential_password_confirm')

let student_last = document.getElementById('enter_student_last')
let student_first = document.getElementById('enter_student_first')
let student_id = document.getElementById('enter_student_id')
let student_photo = document.getElementById('enter_student_id');


//define admin funcitons
function checkSubmission(options, form){
    let emptyField = []
    console.log(options)
    emptyField = emptyFields(options)
    if (emptyField[0] != null){
      alertMessage = 'The following fields are empty:'
      for (field in emptyField){
        alertMessage += '\n' + emptyField[field]
      }
      alert(alertMessage)
    }
    else if (form == 1){
      if (credential_password.value != credential_password_confirm.value){//Check to make sure passwords match on credential creation
        alert("Passwords don't match")
      }
      else{
        submitNewCredentials(form);
      }
    }
    else if (form == 2){//Check to make sure a photo was submitted
      if (student_photo.value == ""){
        alert("No photo attached")
      }
      else{
        submitNewCredentials(form);
      }
    }
}





function emptyFields(dictField){//Check if fields in submit form are empty
  let emptyField = []
  for (x in dictField){
    if (dictField[x].value == ''){
      emptyField.push(x)
      console.log(x)
    }
  }
  console.log('Empty Fields:' + emptyField)
  return emptyField
}






function submitNewCredentials(form){
  let credentialPackage = []
  if (form == 1){
    for (x of ['type','username','password'])
      credentialPackage.push(document.getElementById('enter_credential_' + x).value);
    console.log(credentialPackage)
    for (x of ['type','username','password','password_confirm'])
      document.getElementById('enter_credential_' + x).value = '';
    }
    if (form == 2){
      for (x of ['first','last','id', 'photo'])
        credentialPackage.push(document.getElementById('enter_student_' + x).value);
      console.log(credentialPackage)
      for (x of ['first','last','id', 'photo'])
        document.getElementById('enter_student_' + x).value = '';
      }
      alert(credentialPackage)
      window.location.href = "admin_verify_input.html";

}




function pass(){
  students = ['cel334,chance,leed','pjc336,parker,cantone','mp3492,michael,palumbo','fn74,steven,nie']
  //pass the student array to the student terminal

  window.location.href = "student_terminal.html";
}
