package compressAndEncryptExamVersion;

public enum EncryptType{
    AES,
    DES
}