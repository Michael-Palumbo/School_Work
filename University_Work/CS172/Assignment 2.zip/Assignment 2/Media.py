
class Media():

    def __init__(self, type, name, rating):
        self.__Type = type
        self.__Name = name
        self.__Rating = rating

    def __str__(self):
        return f"Type: {self.__Type}\nName: {self.__Name}\nRating: {self.__Rating}\n"

    def __repr__(self):
        return str(self)

    # Getters
    def getType(self):
        return self.__Type

    def getName(self):
        return self.__Name

    def getRating(self):
        return self.__Rating

    # Setters
    def setType(self, t):
        self.__Type = t

    def setName(self, n):
        self.__Name = n

    def setRating(self, r):
        self.__Rating = r
