=======
Authors
=======

* Adam Geitgey <ageitgey@gmail.com>

Thanks
------

* Many, many thanks to Davis King (@nulhom)
  for creating dlib and for providing the trained facial feature detection and face encoding models
  used in this library.
* Thanks to everyone who works on all the awesome Python data science libraries like numpy, scipy, scikit-image,
  pillow, etc, etc that makes this kind of stuff so easy and fun in Python.
* Thanks to Cookiecutter and the audreyr/cookiecutter-pypackage project template
  for making Python project packaging way more tolerable.
