from django.shortcuts import render, redirect
from django.http import HttpResponse

# Create your views here.

from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

from .forms import ScheduleForm

@login_required
def index(request):#, teacher_id):

	#form  = ScheduleForm()
	#courses = []
	#print("Hello")
	#try:
		#Student_courses = Student_Course.objects.all()
		#for course in Student_courses:
		#	if not course in courses:
		#		course.append(course)
	#	teacher = User.objects.get(pk=teacher_id)
	#	Teacher_courses = teacher.Schedule.all()
	#except User.DoesNotExist:
	#	raise HttpResponse("Teacher does not exist")
	#contexts = {
	#	"teacher":teacher,
	#	"schedules": Teacher_courses,
		#"form": form,
	#}
	return render(request, "teacher_class.html")#, contexts)

# Might not be used
def addSchedule(request, teacher_id):
	form = ScheduleForm(request.POST)
	print(request.POST['text'])	
	return redirect("teacher",id=teacher_id)


