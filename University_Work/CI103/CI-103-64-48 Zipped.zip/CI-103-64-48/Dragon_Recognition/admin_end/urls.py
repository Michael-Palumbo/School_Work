from django.conf.urls import url
from .views import StudentView, CreateCourse
from . import views
from django.contrib.auth.views import LoginView, LogoutView

from django.urls import path
from django.contrib.auth import views as Auth_views

urlpatterns = [

    path('login/',Auth_views.LoginView.as_view(template_name='login_page.html'),name='login'),
    path('logout/',Auth_views.LogoutView.as_view(template_name='index.html'), name='logout'),

    #url(r'^login$',  LoginView.as_view(template_name='login_page.html'), name='login'),

    #url(r'^logout$', LogoutView.as_view(template_name='login_page.html'), name='logout'),
    #url(r'^/home/$',  name='home'),
    url(r'^register$',  views.CredentialRegister, name='register'),
    url(r'^student$', StudentView.as_view(), name='student entry'),  # inherit StudentView Class from views.py
    url(r'^create_course$', CreateCourse.as_view(), name='create course'),
    url(r'^teacher_course$', views.ScheduleCourse.as_view(), name='teacher course'),
    url(r'^student_course$', views.StudentCourse.as_view(), name='student course'),
    url(r'^submission_done$', views.Submitted, name='submit')

    # url('', views.loadIndex, name="index"),

]
