from django import forms
from admin_end.models import Student, Course, Schedule_Course, Student_Course
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class StudentForm(forms.ModelForm):  # Question: do we need user = models.ForeignKey(User, on_delete=models.CASCADE) for secure user??
    student_first_name = forms.CharField(label='Student First Name', max_length=35)  # this is the form passed into html to get student info
    student_last_name = forms.CharField(label='Student Last Name', max_length=35)
    student_id = forms.CharField(label='Student ID', max_length=12)
    student_photo = forms.ImageField(label='Student Photo')

    class Meta:
        abstract = True
        model = Student
        fields = ('student_first_name', 'student_last_name', 'student_id', 'student_photo')  # must add comma to make it a tuple


class CredentialForm(UserCreationForm):  #custom usercreationform
    # declare the fields you will show
    username = forms.CharField(max_length=35, label="Username")
    first_name = forms.CharField(label="First Name")
    last_name = forms.CharField(label="Last Name")
    email = forms.EmailField(max_length=254, label="Email")
    # first password field
    password1 = forms.PasswordInput()
    # confirm password field
    password2 = forms.PasswordInput()

    # this sets the order of the fields
    class Meta:
        model = User
        fields = ("username", "first_name", "last_name", "email", "password1", "password2",)

    # this redefines the save function to include the fields you added
    def save(self, commit=True):
        user = super(UserCreationForm, self).save(commit=False)
        user.first_name = self.cleaned_data["first_name"]
        user.last_name = self.cleaned_data["last_name"]
        user.email = self.cleaned_data["email"]
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.is_staff = True
            user.is_admin = True
            user.is_superuser = True
            user.save()
            return user


class CreateCourseForm(forms.ModelForm):
    course_id = forms.CharField(label='Course ID', max_length=10)
    course_name = forms.CharField(label='Course Name', max_length=20)
    course_start = forms.CharField(label='Course Start Time', max_length=20)
    course_end = forms.CharField(label='Course End Time', max_length=20)

    class Meta:
        abstract = True
        model = Course
        fields = ('course_id', 'course_name', 'course_start', 'course_end')  # must be exactly the same as the previous attribute name


class ScheduleCourseForm(forms.ModelForm):
    schedule_course_id = forms.CharField(label='Schedule Course ID', max_length=10)
    course_id = forms.ModelChoiceField(label='Course ID', queryset=Course.objects.all())
    teacher_id = forms.ModelChoiceField(label='Teacher ID', queryset=User.objects.all())

    class Meta:
        model = Schedule_Course
        fields = ('schedule_course_id', 'course_id', 'teacher_id')


class StudentCourseForm(forms.ModelForm):
    student_course_id = forms.CharField(label='Student Course ID', max_length=200)
    schedule_course_id = forms.ModelChoiceField(label='Schedule Course ID', queryset=Schedule_Course.objects.all())
    student_id = forms.ModelChoiceField(label='Student ID', queryset=Student.objects.all())

    class Meta:
        model = Student_Course
        #unique_together = ('schedule_course_id', 'student_id')
        fields = ('student_course_id', 'schedule_course_id', 'student_id')

