#lecture notes
class Node():
    def __init__(self, data, next = None, prev = None):
        self.__data = data
        self.__next = next

    def __str__(self):
        return str(self.__data)

    def getNext(self):
        return self.__next

    def setNext(self, next):
        self.__next = next


    def getData(self):
        return self.__data
