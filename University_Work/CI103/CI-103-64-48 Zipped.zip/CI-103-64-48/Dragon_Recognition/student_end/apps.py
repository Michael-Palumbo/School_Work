from django.apps import AppConfig


class FacialRecognitionConfig(AppConfig):
    name = 'facial_recognition'
