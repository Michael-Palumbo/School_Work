#Micahel Palumbo, mp3492
#Create a working frame work for a playlist

from Media import *
from Movie import *
from Song import *
from Picture import *
import sys

List_of_Media = [
                    Movie("Movie", "Heathers", "9.4/10", "Michael Lehmann", "1:43"),
                    Song("Song","The Longest Time","7.2/10","Billy Joel","An Innocent Man"),
                    Picture("Picture", "Mona Lisa.png","10/10","960"),
                    Movie("Movie", "The Breakfast Club", "8.8/10", "John Hughes", "1:37"),
                    Song("Song","Mr. Blue Sky","7.4/10","Elctric Light Orchestra","Out of the Blue"),
                    Picture("Picture", "The Scream.png","9/10","960"),
                    Movie("Movie", "Back to the Future", "9.6/10", "Robert Zemeckis", "1:56"),
                    Song("Song","Californication","7.8/10","Red Hot Chili Peppers","Californication"),
                    Picture("Picture","The Starry Night.png","9.5/10","960"),
                    Movie("Movie", "The Mist", "7.2/10", "Frank Darabont", "2:06"),
                    Movie("Movie", "Jurassic Park", "6.8/10", "Steven Spielberg", "2:07"),
                    Song("Song","Wouldn't it Be Nice","8/10","Beach Boys","Pet Sounds"),
                ]

def printf(media):
    print("-"*30)
    print(media)

# Take input and seperate it into a command portion and contents of the command
def parseInput(inp):
    try:
        # Get the First Word
        command = inp.split()[0].lower()
        try:
            # Get the remaining words after the first
            contents = inp[inp.index(' ')+1:].lower()
            return command, contents
        except:
            return command, None
    except KeyboardInterrupt:
        sys.exit(0)
    except:
        return None,None
# Just the list of Commands
def helpCommands():
    print("="*30)
    print("Here are the Commands:")
    print(">> Display All --> Displays the contents of the pre-installed List")
    print(">> Display {media type} --> Displays the contents of a certain catagory\n\t\t\t    Media types are [Movies, Songs, Pictures]")
    print(">> Play {name of item} --> It will play of show the item you named respectivly")
    print(">> Quit --> Closes the Pro   gram")
    print(">> Help --> Reprint the command list")
    print("="*30,'\n')

if __name__ == "__main__":
    print("Welcome to Assignment 2")
    helpCommands()

    # We keep running until they quit
    while True:
        inp = input("What is your choice:\n>> ")
        command, contents = parseInput(inp)

        # Where the switch statements at?
        if command == "display":

            if contents == "all":
                for current_media in List_of_Media:
                    printf(current_media)

            # List of Possible Types
            elif contents in ["movie","song","picture"]:
                # Filters out anything that isn't the specified type, Filter needs a callback that returns true or false, item is the current item filter is looping through
                for current_media in list(filter(lambda item:item.getType().lower() == contents ,List_of_Media)):
                    printf(current_media)
            else:
                print(f"Invalid Type: {contents}")

        elif command == "play":

            for s in List_of_Media:
                # Picture does not have a play method, so we filter them out
                if(s.getType().lower() != "picture" and contents == s.getName().lower()):
                        s.play()
                        break
            else:
                print(f"Invalid Name: {contents}")

        elif command == "show":

            for s in List_of_Media:
                # Only picture has a show method
                if(s.getType().lower() == "picture" and contents == s.getName().lower()):
                        s.show()
                        break
            else:
                print(f"Invalid Name: {contents}")

        elif command == "help":
            helpCommands()

        # Quit, but with other keywords, that could be used
        elif command in ["quit","exit","leave","logout"]:
            print("Have a good day!")
            break

        else:
            print(f"Unrecognized Command: {command}")
