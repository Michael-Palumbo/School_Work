from django.urls import path
from student_end import views

urlpatterns = [
    #path("", views.index)
]
