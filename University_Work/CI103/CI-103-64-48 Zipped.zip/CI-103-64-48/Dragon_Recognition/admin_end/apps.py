from django.apps import AppConfig


class AdminEndConfig(AppConfig):
    name = 'admin_end'
