import os
from admin_end.forms import StudentForm, CreateCourseForm, CredentialForm, ScheduleCourseForm, StudentCourseForm

from django.views.generic import TemplateView
from django.shortcuts import render
from django.contrib.auth import login, authenticate
from django.http import HttpResponse
from django.views.generic import CreateView
from .models import Schedule_Course, Student_Course
from django.urls import reverse_lazy
#from django.contrib import messages

from django.contrib.auth.decorators import login_required

# def logout():
#     return render(request, template_name='login_page.html')


def loadIndex(request):
    return render(request,'index.html')

class StudentView(TemplateView):
    template_name = os.path.join('admin_student.html')

    def get(self, request):
        form = StudentForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = StudentForm(request.POST, request.FILES)  # view function to save the student form into database
        if form.is_valid():
            post = form.save(commit=False)
            #text = form.cleaned_data['student_first_name', 'student_last_name', 'student_id', 'student_photo']
            #post.user = request.user
            post.save()
            #form = StudentForm()
            return render(request, os.path.join('admin_verify_input.html'))
        else:
            return HttpResponse('Please upload a valid photo')

@login_required
def CredentialRegister(request):  # this is a function, not a class
    if request.method == 'POST':  # view function to save the student form into database
        form = CredentialForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return render(request, 'admin_verify_input.html')
        else:
            return render(request, 'admin_credentials.html', {'form': form})
    else:
        form = CredentialForm()  # make sure both form is using the correct custom form CredentialForm()
        return render(request, 'admin_credentials.html', {'form': form})


class CreateCourse(TemplateView):
    template_name = os.path.join('admin_createcourse.html')

    def get(self, request):
        form = CreateCourseForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = CreateCourseForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.save()
            return render(request, os.path.join('admin_verify_input.html'))
        else:
            return HttpResponse('Please enter valid information for courses')


class ScheduleCourse(CreateView):
    template_name = os.path.join('admin_addteachercourse.html')
    model = Schedule_Course
    form_class = ScheduleCourseForm
    success_url = reverse_lazy('submit')


class StudentCourse(CreateView):
    template_name = os.path.join('admin_addstudentcourse.html')
    model = Student_Course
    form_class = StudentCourseForm
    success_url = reverse_lazy('submit')


def Submitted(request):  # view function for showing the 'Thank you for submission page'
    return render(request, 'admin_verify_input.html')
