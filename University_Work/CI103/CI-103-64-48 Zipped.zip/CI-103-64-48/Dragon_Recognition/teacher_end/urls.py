from django.conf.urls import url
from django.urls import path

from . import views

urlpatterns = [
	# url(r'^teacher$', views.index, name='teacher'),
	# url(r'^add$', views.addSchedule, name="add")

	path('', views.index, name="teacher"),

	#path('<slug:teacher_id>',views.index, name="teacher"),
	#path('<slug:teacher_id>', views.addSchedule, name="add"),
]
