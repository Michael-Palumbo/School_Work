from Media import *

class Movie(Media):

    def __init__(self, type, name, rating, dir, runningTime):
        super().__init__(type, name, rating)
        self.__Director = dir
        self.__RTime = runningTime

    # Calls the inherited string method and then attaches it's own properties
    def __str__(self):
        return super().__str__() + f"Director: {self.__Director}\nRunning Time: {self.__RTime}\n"

    def play(self):
        print(f"{super().getName()}, playing now\n")

    # Getters
    def getDirector(self):
        return self.__Director

    def getRunTime(self):
        return self.__RunTime

    # Setters
    def setDirector(self, d):
        self.__Director = d

    def setRunTime(self, rt):
        self.__RunTime = rt
