from django.apps import AppConfig


class TeacherEndConfig(AppConfig):
    name = 'teacher_end'
