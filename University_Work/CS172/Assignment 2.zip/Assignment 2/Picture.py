from Media import *

class Picture(Media):

    def __init__(self, type, name, rating, Resolution):
        super().__init__(type, name, rating)
        self.__Resolution = Resolution

    def show(self):
        print(f"Showing {super().getName()}\n")

    # Calls the inherited string method and then attaches it's own properties
    def __str__(self):
        return super().__str__() + f"Resolution: {self.__Resolution}\n"

    # Getters
    def getResolution(self):
        return self.__Resolution

    # Setters
    def setResolution(self, r):
        self.__Resolution = r
