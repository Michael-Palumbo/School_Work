from django import forms

class ScheduleForm(forms.Form):
	temp_widget = forms.TextInput( attrs = {'style': 'float:right'})
	text = forms.CharField(max_length=40, widget = temp_widget)

