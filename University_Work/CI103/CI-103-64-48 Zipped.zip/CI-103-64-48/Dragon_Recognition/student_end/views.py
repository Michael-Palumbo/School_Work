from django.template import loader

from django.shortcuts import render

import face_recognition


# Create your views here.
#def index(request):
    #template = loader.get_template()