from django.contrib import admin

from .models import Student

from .models import Course, Student_Course, Schedule_Course,  Student

# Register your models here.
class StudentAdmin(admin.ModelAdmin):
    pass




admin.site.register(Student, StudentAdmin)
admin.site.register(Schedule_Course)
admin.site.register(Course)
admin.site.register(Student_Course)