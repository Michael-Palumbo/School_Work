from Media import *

class Song(Media):

    def __init__(self, type, name, rating, Artist, Album):
        super().__init__(type, name,rating)
        self.__Artist = Artist
        self.__Album = Album

    # Calls the inherited string method and then attaches it's own properties
    def __str__(self):
        return super().__str__() + f"Artist: {self.__Artist}\nAlbum: {self.__Album}\n"

    def play(self):
        print(f"{super().getName()} by {self.__Artist} is now playing\n")

    # Getters
    def getArtist(self):
        return self.__Artist

    def getAlbum(self):
        return self.__Album

    # Setters
    def setArtist(self, d):
        self.__Artist = d

    def setAlbum(self, rt):
        self.__Album = rt
