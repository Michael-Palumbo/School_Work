package compressAndEncryptExamVersion;

public enum DecryptType{
    GOOD_COMP,
    BAD_COMP
}