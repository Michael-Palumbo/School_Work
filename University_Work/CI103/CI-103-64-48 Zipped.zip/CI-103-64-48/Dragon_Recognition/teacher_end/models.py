import sys

sys.path.append("..")

# from django.db import models

from admin_end.models import Student, Course


# Create your models here.

# class Student(models.Model):
#	first = models.CharField(max_length=30)
#	last = models.CharField(max_length=30)
#
#	def __str__(self):
#		return "%s %s"%(self.first, self.last)


# class Teacher(models.Model):
#     teacher_id = models.CharField(primary_key=True, max_length=10)
#     first = models.CharField(max_length=30)
#     last = models.CharField(max_length=30)
#
#     # schedules = models.ManyToManyField(Schedule, blank=True, related_name="teachers")
#
# # def __str__(self):
# # 	return "%s %s"%(self.first, self.last)
#
#
# class Schedule_Course(models.Model):
#     schedule_course_id = models.CharField(primary_key=True, max_length=64)
#     course_id = models.ForeignKey(Course, on_delete=models.CASCADE)
#     teacher_id = models.ForeignKey(Teacher, on_delete=models.CASCADE)
#
# # students = models.ManyToManyField(Student, blank=True, related_name="schedules")
# # name = models.CharField(max_length=64)
# # start = models.CharField(max_length=64)
# # end = models.CharField(max_length=64)
#
# # def __str__(self):
# # 	return "Class: %s Starts: %s Ends: %s"%(self.name, self.start, self.end)
# #
# # def getTime(self):
# # 	return "%s - %s"%(self.start,self.end)
#
#
# class Student_Course(models.Model):
#     student_course_id = models.CharField(max_length=64, primary_key=True)
#     schedule_course_id = models.ForeignKey(Schedule_Course, on_delete=models.CASCADE)
#     student_id = models.ForeignKey(Student, on_delete=models.CASCADE)
#     attend = models.BooleanField(default=False)
