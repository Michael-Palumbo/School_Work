# Dragon Recognition #

## Description: ##
We seek "Attendance made Effortless"
Our goal is to create an attendance system for the high school or college level setting that allows a student to walk into class, then get marked present using facial recognition software. The teacher will be able to customize their classes to account for what students are expected, the name of the class, and start/end times.

This project is made for three main users, teachers, students, and administrators.

The **_teachers_** should be able to create a class that consists primarily of an attendance list. Once the class is created, it can be initiated to begin taking attendance for that class, then once the class attendance taking has ended, the teacher can end the session and their account will receive an attendance report on their account. This will show who was marked present and who was not.

**_Students_** should have the easiest user experience, where they walk up to the laptop the program is being run on, have their face in the camera field, once a box forms around their face, they can capture the photo, marking them present if they are recognized. Otherwise it will ask them to try again. Once this is done, they are done

An **_administrator_** will have access to their own end of the website that will allow them to add new teacher accounts and new students.


## Technologies: ##

	Front End:
		HTML5
		CSS
		Javascript

	Back End:
		Python3
		Django
		SQL
		Machine Learning
		OpenCV

## Installations: ##
	django
	cmake
	dlib
	facial_recognition
	numv
	openCV-python
	pip
	pillow

## Contributing: ##
	The project is not currently open to contributions however that may change in the near future

## Authors and Acknowledgment: ##
*		Chance Leed			cel334@drexel.edu
*		Parker Cantone	pjc336@drexel.edu
*		Michael Palumbo mp3492@drexel.edu
*		Steven Nie			fn74@drexel.edu


## License: ##
	MIT

## Project Status: ##
	Work in progress
